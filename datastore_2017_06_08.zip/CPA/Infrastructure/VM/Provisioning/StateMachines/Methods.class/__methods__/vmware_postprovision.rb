prov = $evm.root["miq_provision"]
vm = $evm.root['vm']

puts "POST_PROV"

$evm.instantiate '/ObjectWalker/ObjectWalker/objectwalker'


