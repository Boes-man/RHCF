require 'net/ldap' # gem install ruby-net-ldap

  ### BEGIN CONFIGURATION ###
  SERVER = $evm.object['ldap_host']   # Active Directory server name or IP
  PORT = $evm.object['ldap_port']                    # Active Directory server port (default 389)
  BASE = $evm.object['ldap_base']    # Base to search from
  DOMAIN = $evm.object['ldap_domain']        # For simplified user@domain format login
  login = $evm.object['ldap_svcuser']
  pass = $evm.object.decrypt('ldap_pass')
  SSL = ':simple_tls'
  ### END CONFIGURATION ###

=begin  @task = $evm.root['miq_provision_request'] || $evm.root['miq_provision'] || $evm.root['miq_provision_request_template']
  usr = @task.miq_provision_request.userid
  group = task.get_option(:dialog)['dialog_cx_project_id']
  u = usr.split("@")
  user = u[0]
=end
user = 'CPPDDW'
group = 'imt12345'

    conn = Net::LDAP.new :host => SERVER,
                         :port => PORT,
                         :base => BASE,
                         :encryption => SSL,
                         :auth => { :username => "#{login}@#{DOMAIN}",
                                    :password => pass,
                                    :method => :simple }
    if conn.bind
      #$evm.log(:info, "LDAP bind success")
      filter  = "(&(cn=*)(sAMAccountName=#{user}))"
      conn.search(:base => "#{BASE}", :filter => "#{filter}") do |object|
        @results = object.memberOf.to_s
        if @results.include? "#{group}" then
          project_ad = true
          $evm.log(:info, "#{user} is a member of #{group}")
        end
      end
    else
        p conn.get_operation_result
      $evm.log(:info, "LDAP bind failed")
    end
