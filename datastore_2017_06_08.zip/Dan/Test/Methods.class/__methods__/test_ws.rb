#
# Description: <Method description here>
#
  @task = $evm.root['service_template_provision_task']

  @task.miq_request_tasks.set_option(:ws_value)[:cluster_name=>'IMC3_NonProd_Blue_Clus', :zone=> 'Blue', :vmnet=>'Non-Prod-TN|Non-Prod-AP|Blue-1214-IMC3-EPG']
  ws_values = @task.miq_request_tasks.options[:ws_values]
  $evm.log("info", "Setting options: #{ws_values}")
